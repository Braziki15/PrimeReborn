# /etc/DNS_MANAGER/dns_manager.py

# DNS Manager, DNS Requests Receiver - Created by StackMTL

import os
from flask import Flask, request, jsonify
import subprocess
import re

app = Flask(__name__)

CONF_FOLDER = "/etc/DNS_MANAGER/.conf/"
AUTHORIZED_IPS_FILE = os.path.join(CONF_FOLDER, "authorized_ips.txt")
UPDATE_SCRIPT = "/etc/DNS_MANAGER/dns_update.sh"
NSUPDATE_FILE = "/tmp/nsupdate_cmds.txt"
TSIG_KEY_FILE = "/etc/bind/rndc.key"

def check_authorization(client_ip):
    try:
        # Re-read the IP file on each call to avoid caching issues
        with open(AUTHORIZED_IPS_FILE, 'r') as f:
            for line in f:
                # Ignore comments and whitespace
                line = line.split('#')[0].strip()
                if line == client_ip:
                    return True
        return False
    except FileNotFoundError:
        print("Error: authorized_ips.txt file not found.")
        return False

def get_domain_from_bind():
    """Retrieves the primary domain configured in BIND, if possible."""
    try:
        # Use dig or rndc to query for the zone information; here, we assume dig is used
        result = subprocess.run(["dig", "+short", "NS", "@127.0.0.1"], capture_output=True, text=True)
        if result.returncode == 0:
            # Extract domain from the response; assume the first NS record corresponds to the domain
            domain = result.stdout.splitlines()[0].strip('.')
            return domain
    except Exception as e:
        print(f"Error retrieving domain from BIND: {e}")
    return None

def sanitize_host(host, domain):
    """Sanitize the host by removing the domain if it is appended, e.g., 'mail.domain.com' -> 'mail'."""
    if host.endswith(f".{domain}"):
        host = host[:-(len(domain) + 1)]
    return host

def validate_inputs(action, host, record_type, value=None):
    """Validates inputs, allowing only valid hosts and record types."""
    forbidden_hosts = {"@", "www", "ns1", "ns2"}
    valid_record_types = {"A", "AAAA", "CNAME", "TXT", "MX"}

    # Block any modification attempts to restricted hosts
    if host in forbidden_hosts:
        return False, "Modifications to @, www, ns1, and ns2 are restricted."

    # Ensure record type is valid
    if record_type not in valid_record_types:
        return False, "Invalid record type."

    # Validate IPv4/IPv6 for A/AAAA records
    if record_type == "A" and value:
        if not re.match(r"^(?:\d{1,3}\.){3}\d{1,3}$", value):
            return False, "Invalid IPv4 address format."
    elif record_type == "AAAA" and value:
        if not re.match(r"^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$", value):
            return False, "Invalid IPv6 address format."

    return True, ""

def call_dns_script(client_ip, data):
    # Check authorization
    if not check_authorization(client_ip):
        return jsonify({"status": "error", "code": 401, "message": "UNAUTHORIZED"}), 401

    # Retrieve domain from BIND dynamically
    domain = get_domain_from_bind()
    if not domain:
        return jsonify({"status": "error", "message": "Domain retrieval failed"}), 500

    action = data.get("action")
    zone = data.get("zone", domain)  # Use the domain as default if zone is not specified
    host = sanitize_host(data.get("host", ""), domain)
    record_type = data.get("type")
    value = data.get("value", "")

    # Validate inputs
    is_valid, validation_msg = validate_inputs(action, host, record_type, value)
    if not is_valid:
        return jsonify({"status": "error", "message": validation_msg}), 400

    try:
        with open(NSUPDATE_FILE, 'w') as f:
            f.write(f"server 127.0.0.1\n")
            f.write(f"zone {zone}\n")
            f.write(f"key update_key {TSIG_KEY_FILE}\n")

            if action.lower() == "add":
                # First, delete any existing record of the same name and type
                f.write(f"update delete {host}.{zone} {record_type}\n")
                f.write(f"update add {host}.{zone} 86400 {record_type} {value}\n")
            elif action.lower() == "delete":
                f.write(f"update delete {host}.{zone} {record_type}\n")
            else:
                return jsonify({"status": "error", "message": "Invalid action"}), 400

            f.write("send\n")

        # Execute the update script
        result = subprocess.run([UPDATE_SCRIPT, NSUPDATE_FILE], capture_output=True, text=True)

        if result.returncode != 0:
            return jsonify({"status": "error", "message": result.stderr}), 500

        return jsonify({"status": "success", "message": "DNS updated successfully"}), 200

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"status": "error", "message": "Internal server error"}), 500

@app.route('/dns', methods=['POST'])
def dns():
    client_ip = request.remote_addr
    data = request.get_json()
    return call_dns_script(client_ip, data)

# Block every others requests with error 404
@app.errorhandler(404)
def page_not_found(e):
    return jsonify({"status": "error", "code": 404, "message": "The requested resource was not found."}), 404

if __name__ == '__main__':
    app.run(port=5001)
