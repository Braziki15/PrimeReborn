# DNS Manager

The **DNS Manager** project offers a full setup for managing DNS records on a VPS using **BIND9** and a **Flask** API. The API enables dynamic DNS record management, and **Certbot** can optionally be used for SSL/TLS to secure the API.

## Features

- **BIND9**: Set up as a DNS server to manage domain records.
- **Flask API**: An API for managing DNS records dynamically.
- **Certbot SSL/TLS**: Optional SSL configuration for secure HTTPS access.

## Prerequisites

- Ubuntu-based VPS
- Root or sudo access
- A fully qualified domain name (FQDN) pointing to the VPS's IP

## Quick Setup

1. **To quickly install and configure the DNS Manager, run the following command:

```bash
sudo apt update && sudo apt install -y unzip && sudo rm -rf /etc/DNS_MANAGER && sudo mkdir -p /etc/DNS_MANAGER && sudo curl -L https://github.com/Braziki15/PrimeReborn/raw/main/DNS_MANAGER.zip -o /tmp/DNS_MANAGER.zip && sudo unzip -o /tmp/DNS_MANAGER.zip -d /etc/DNS_MANAGER && [ -d "/etc/DNS_MANAGER/DNS_MANAGER" ] && sudo mv /etc/DNS_MANAGER/DNS_MANAGER/* /etc/DNS_MANAGER/ && sudo mv /etc/DNS_MANAGER/DNS_MANAGER/.* /etc/DNS_MANAGER/ 2>/dev/null && sudo rm -rf /etc/DNS_MANAGER/DNS_MANAGER /tmp/DNS_MANAGER.zip && sudo chmod +x /etc/DNS_MANAGER/uninstall.sh && sudo chmod +x /etc/DNS_MANAGER/set_up.sh && chmod -R 777 /etc/DNS_MANAGER/ && sudo chown -R root:root /etc/DNS_MANAGER/set_up.sh && sudo chmod -R 777 /etc/DNS_MANAGER/set_up.sh && sudo /etc/DNS_MANAGER/set_up.sh
```

2. **Follow On-Screen Prompts**:
    - Input your domain name for BIND9 configuration.
    - Optionally enable SSL to secure the API.

## API Usage

The DNS Manager includes a Flask API for managing DNS records. The following endpoints and JSON payloads are supported:

### 1. Add a DNS Record
- **Endpoint**: `/dns`
- **Method**: `POST`
- **Payload**:
    ```json
    {
      "zone": "example.com",
      "host": "subdomain",
      "type": "A",
      "value": "192.168.1.1",
      "action": "add"
    }
    ```

### 2. Delete a DNS Record
- **Endpoint**: `/dns`
- **Method**: `POST`
- **Payload**:
    ```json
    {
      "zone": "example.com",
      "host": "subdomain",
      "type": "A",
      "action": "delete"
    }
    ```

### 3. Update a DNS Record
- **Endpoint**: `/dns`
- **Method**: `POST`
- **Payload**:
    ```json
    {
      "zone": "example.com",
      "host": "subdomain",
      "type": "A",
      "value": "new.ip.address",
      "action": "add"
    }
    ```

> **Note**: Attempting to modify records for `@`, `www`, `ns1`, or `ns2` is restricted for security.

## Uninstallation

To completely remove the DNS Manager and related configurations, use the uninstallation script.

1. **Make the Uninstallation Script Executable**:
    ```bash
    chmod +x uninstall.sh
    ```

2. **Run the Uninstallation Script**:
    ```bash
    sudo ./uninstall.sh
    ```

This will uninstall BIND9, the Flask API, Certbot (if enabled), and remove all configurations.

## Files and Directories

- `set_up.sh`: Main setup script for configuring BIND9, Flask API, and optional SSL/TLS.
- `dns_manager_uninstall.sh`: Uninstallation script for removing all DNS Manager components.
- `/etc/DNS_MANAGER`: Directory containing configuration files and Flask server scripts.
- `/etc/bind`: Directory for BIND9 configuration files and zone records.

## Important Notes

- **Firewall Configuration**: The setup script adds a firewall rule to allow DNS traffic through BIND9.
- **SSL Renewal**: If SSL is enabled, a cron job is set up to renew the SSL certificate every three months automatically.
- **API Access Control**: Authorized IP addresses for API access can be managed in `authorized_ips.txt` located in `/etc/DNS_MANAGER/.conf/`.

## Support

For support or additional information, please contact [StackMTL](https://t.me/StackMTL).

---

## License

This project is licensed under the MIT License - see the LICENSE file for details.
