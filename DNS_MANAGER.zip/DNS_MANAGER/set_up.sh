#!/bin/bash

# DNS Manager, Set Up Script - Created by StackMTL

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "     🌐 DNS Manager Configuration Tool        "
echo "           Powered by StackMTL               "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Making sure the script is running as root or sudo
if [ "$(id -u)" -ne 0 ]; then
    echo "Error: Root permissions not Allowed. Run this script as root or use sudo."
    echo ""
    echo " -- Exiting set up script.."
    exit 1
fi

# Check if the file exists
SETUP_FILE="/etc/DNS_MANAGER/.conf/setup_continue"

if [ ! -f "$SETUP_FILE" ]; then
    echo "File $SETUP_FILE not found. Creating it with the default value (0)."
    echo "0" > "$SETUP_FILE"
fi

# Read the file content
SETUP_STATE=$(cat "$SETUP_FILE" | tr -d '[:space:]')  # Remove spaces or invisible characters

# Check the value
if [ "$SETUP_STATE" == "1" ]; then
    echo "Setup is in progress... (value 1 detected)"
elif [ "$SETUP_STATE" == "0" ]; then
    echo "Setup is not started or stopped. (value 0 detected)"
else
    echo "Invalid value detected in $SETUP_FILE. Resetting to 0."
    echo "0" > "$SETUP_FILE"
fi

if [ "$SETUP_STATE" == "0" ]; then
  # Asking the domain to configure and confirm
  while true;
  do
      read -p "Insert the domain to configure (e.g. : example.com) : " DOMAIN
      read -p "You inserted '$DOMAIN'. Do you confirm ? (y/n): " CONFIRM
      if [[ "$CONFIRM" == "y" || "$CONFIRM" == "Y" ]]; then

          echo "You confirmed for '$DOMAIN'. Bind will be configured for this domain."
          break

      elif [[ "$CONFIRM" == "n" || "$CONFIRM" == "n" ]]; then
          echo "You refused the confirmation for the domain '$DOMAIN'. Please try again."
      else
          echo "Wrong input. Please try again."
      fi
  done

  # Save main domain in a config file
  main_domain_file="/etc/DNS_MANAGER/.conf/main_domain.conf"
  cat > "$main_domain_file" <<EOL
# This is the main domain. Do not modify it.

$MAIN_DOMAIN
EOL

  # System update

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Updating system..."
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  sudo apt update
  sudo apt upgrade -y


  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  System updated!"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  # Bind and utils installation

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Installing BIND9 and others utils..."
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  sudo apt install -y bind9 bind9utils bind9-doc

  # Automatically detect the BIND9 service name and enable/start it
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Enabling BIND9 and starting service..."
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  BIND_SERVICE=$(systemctl list-units --type=service | grep -Ei 'bind9|named' | awk '{print $1}' | head -n 1)

  if [ -n "$BIND_SERVICE" ]; then
      echo "Found BIND9 service: $BIND_SERVICE. Enabling and starting..."
      sudo systemctl enable "$BIND_SERVICE"
      sudo systemctl start "$BIND_SERVICE"
  else
      echo "Error: BIND9 service not found. Please check your installation."
      exit 1
  fi

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Verifying BIND9's status..."
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  status=$(systemctl is-active $BIND_SERVICE)

  # Get and show bind service status
  if [ "$status" = "active" ]; then
      echo "============================================="
      echo "  BIND9's is installed and active!"
      echo "============================================="

  else
      echo "━[!!!]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
      echo "  Error: BIND9 didn't started successfully.  "
      echo "  Please check configuration or restart the  "
      echo "  the system.  "
      echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
      echo ""
      echo " -- Exiting set up script..."
      exit 1
  fi

  # Allowing BIND9 to work through the firewall

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Allowing BIND9 to work through the firewall..."
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  sudo ufw allow 53/tcp
  sudo ufw allow 53/udp
  sudo ufw allow bind9
  sudo ufw reload

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Configuring named.conf.options..."
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  OPTIONS_FILE="/etc/bind/named.conf.options"

  sudo bash -c "cat > $OPTIONS_FILE <<EOL
  options {
      directory "/var/cache/bind";

      // Allow requests from all clients
      allow-query { any; };

      // Listen on all IPv4 interfaces
      listen-on { any; };

      // Disable DNSSEC validation
      dnssec-validation no;

      // Disable NXDOMAIN redirection
      auth-nxdomain no;

      // Disable IPv6
      listen-on-v6 { none; };
  };

  EOL"

  # Check the BIND9 syntax configuration
  sudo named-checkconf

  # If no errors are returned, restart BIND9
  if [ $? -eq 0 ]; then
      sudo systemctl restart $BIND_SERVICE
      status=$(systemctl is-active $BIND_SERVICE)
      if [ "$status" = "active" ]; then
          echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
          echo "  BIND9 options has been successfully configured  "
          echo "  and restarted!"
          echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
      else
          echo "━[!!!]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
          echo "  Error: BIND9 didn't started successfully.  "
          echo "  Please check configuration or restart the  "
          echo "  the system.  "
          echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
          echo ""
          echo " -- Exiting set up script..."
          exit 1
      fi

  else
      echo "━[!!!]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
      echo "  Error: In BIND9 syntax configuration.      "
      echo "  Please check configuration file.           "
      echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
      echo ""
      echo " -- Exiting set up script..."
      exit 1
  fi

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Creating zone file for the                 "
  echo "  domain '$DOMAIN'...                        "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  ZONE_FILE="/etc/bind/db.$DOMAIN"            # Path to the zone file
  NAMED_CONF="/etc/bind/named.conf.local"     # Path to named.conf.local


  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Giving BIND full perms...                  "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  sudo chown -R bind:bind /etc/bind
  sudo chmod -R 777 /etc/bind

  # This defines a zone for the domain and specifies the file where DNS records for this domain will be stored:
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Configuring zone file for the domain '$DOMAIN'. "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  sudo bash -c "cat > $NAMED_CONF <<EOL

  zone \"$DOMAIN\" {
      type master;
      file \"$ZONE_FILE\";
      allow-update { 127.0.0.1; };
  };
  EOL"

  # Zone file creation
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Creating the zone file for '$DOMAIN'"
  echo "  at $ZONE_FILE..."
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  sudo cp /etc/bind/db.empty $ZONE_FILE     # Start with an empty template file

  # Edit the zone file with necessary DNS records

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Preparing to write DNS records to the      "
  echo "  zone file '$ZONE_FILE'...                  "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  # Get IP from the hostname and validate it with the user
  IP_ADDRESS=$(hostname -I | awk '{print $1}')

  echo ""
  while true;
  do
      read -p "IPV4 that will be configured for this actual DNS Server: '$IP_ADDRESS'. Do you confirm ? (y/n): " CONFIRM
      if [[ "$CONFIRM" == "y" || "$CONFIRM" == "Y" ]]; then

          echo "You confirmed for '$IP_ADDRESS'. Bind will be configured for this IPV4."
          break

      elif [[ "$CONFIRM" == "n" || "$CONFIRM" == "n" ]]; then
          echo "You refused the confirmation for the IPV4 '$IP_ADDRESS'."
          read -p "Write the ipv4 for this DNS Server: " IP_ADDRESS
      else
          echo "Wrong input. Please try again."
      fi
  done

  # Writing the records
  echo "=============================================================================="
  echo "This configuration will define:"
  echo "- SOA (Start of Authority) record: Basic info about '$DOMAIN'"
  echo "- NS (Nameserver) records: Specify the nameservers for '$DOMAIN'"
  echo "- A records: Map domain names (like '$DOMAIN' and www) to the IP address"
  echo "=============================================================================="

  # Write the new content to the file, escaping $TTL to avoid variable substitution
  bash -c "cat <<EOF > $ZONE_FILE
  \\\$TTL 604800
  @       IN      SOA     ns1.$DOMAIN. admin.$DOMAIN. (
                 2         ; Serial
            604800         ; Refresh
             86400         ; Retry
           2419200         ; Expire
            604800 )       ; Minimum TTL

  @       IN      NS      ns1.$DOMAIN.
  @       IN      NS      ns2.$DOMAIN.

  ns1     IN      A       $IP_ADDRESS
  ns2     IN      A       $IP_ADDRESS

  @       IN      A       $IP_ADDRESS
  www     IN      A       $IP_ADDRESS
  EOF"


  # Verify the BIND9 configuration syntax to ensure there are no errors
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Checking BIND9 configuration syntax             "
  echo "  and restarting...                               "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  sudo named-checkconf                    # Verifies syntax for overall BIND configuration
  sudo named-checkzone $DOMAIN $ZONE_FILE # Verifies syntax and data for the

  # If no errors are returned, restart BIND9
  if [ $? -eq 0 ]; then
      sudo systemctl restart $BIND_SERVICE
      status=$(systemctl is-active $BIND_SERVICE)
      if [ "$status" = "active" ]; then
          echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
          echo "  BIND9 options has been successfully restarted!  "
          echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
      else
          echo "━[!!!]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
          echo "  Error: BIND9 didn't started successfully.  "
          echo "  Please check configuration or restart the  "
          echo "  the system.  "
          echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
          echo ""
          echo " -- Exiting set up script..."
          exit 1
      fi

  else
      echo "━[!!!]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
      echo "  Error: In BIND9 syntax configuration.      "
      echo "  Please check configuration file.           "
      echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
      echo ""
      echo " -- Exiting set up script..."
      exit 1
  fi

  echo "Validating BIND9 configuration..."
  sudo named-checkconf
  sudo named-checkzone $DOMAIN $ZONE_FILE

  read -p "Press [ENTER] to continue..." EnterToContinue

  # Installing nsupdate (if necessary)
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Installing nsupdate (if necessary)         "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  if command -v nsupdate &> /dev/null; then
      echo "✅ nsupdate is already installed."
  else
      # Install bind9-utils to get nsupdate
      echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
      echo "  Installing bind9-utils (includes nsupdate)...  "
      echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
      sudo apt update
      sudo apt install -y bind9-utils

      # Verify installation
      if command -v nsupdate &> /dev/null; then
          echo "✅ nsupdate installed successfully."
      else
          echo "❌ Installation failed. Please check your network connection and try again."
          exit 1
      fi
  fi

  # Display nsupdate version to confirm it's working
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Verifying nsupdate installation...         "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  if command -v nsupdate > /dev/null 2>&1; then
      echo "✅ nsupdate is installed and ready to use."
  else
      echo "❌ nsupdate verification failed. Please check the installation."
      exit 1
  fi

  # Installing Python and setting up the virtual environment for Flask
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Downloading Python and its utilities...    "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  sudo apt install -y python3 python3-pip python3-venv

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Setting up virtual environment for Flask... "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  python3 -m venv /etc/DNS_MANAGER/venv
  source /etc/DNS_MANAGER/venv/bin/activate
  pip install flask
  deactivate

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Creating systemd service file...           "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  SERVICE_FILE=/etc/systemd/system/dns_manager.service

  cat <<EOL > $SERVICE_FILE
[Unit]
Description=DNS Manager Flask Service
After=network.target

[Service]
User=root
WorkingDirectory=/etc/DNS_MANAGER
ExecStart=/etc/DNS_MANAGER/venv/bin/python /etc/DNS_MANAGER/dns_localhost.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOL

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Enabling and starting the DNS Manager...   "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  sudo systemctl daemon-reload
  sudo systemctl enable dns_manager
  sudo systemctl start dns_manager

  # Allow DNS Manager API traffic on port 5001
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Opening port 5001 for DNS Manager API..."
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  sudo ufw allow 5001/tcp
  sudo ufw reload


  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Reloading systemd...                      "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  sudo systemctl daemon-reload

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Systemd reloaded!                          "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Starting DNS_MANAGER Flask Server...      "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  sudo systemctl start dns_manager
  sudo systemctl enable dns_manager

  # Verifying if the dns_manager service is active
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Verifying the server status...                          "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  if systemctl is-active --quiet dns_manager; then
      echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
      echo "  ✅ Dns_manager is active and working properly."
      echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  else
      echo "━[!!!]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
      echo "  ❌ The dns_manager service is not active."
      echo "     Please check the log for errors."
      echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

      # Afficher les dernières lignes du journal du service pour diagnostiquer le problème
      sudo journalctl -u dns_manager --no-pager -n 20
      exit 1
  fi

  # SSL/TLS Configuration with Certbot
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Downloading certbot..."
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  sudo apt install -y certbot

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Allowing certbot to work through the firewall..."
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  sudo ufw allow 80/tcp
  sudo ufw allow 443/tcp
  sudo ufw allow certbot
  sudo ufw reload


  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Obtaining SSL certificate for $DOMAIN using Certbot..."
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"



  # Use Certbot to get an SSL certificate
  DOMAIN="$DOMAIN"  # Replace with your domain
  EMAIL="admin@$DOMAIN"    # Replace with your email

  echo "Requesting an SSL certificate for $DOMAIN..."
  certbot certonly --standalone -d "$DOMAIN" --non-interactive --agree-tos -m "$EMAIL"

  # Define the certificate path
  CERT_PATH="/etc/letsencrypt/live/$DOMAIN"
  if [ ! -d "$CERT_PATH" ]; then
      echo "Error: SSL certificate was not generated. Please check Certbot logs for details."
      exit 1
  fi

  echo "SSL certificate successfully generated."
  echo "Certificate path: $CERT_PATH"
  echo "Your Python server should now use the following files:"
  echo " - Certificate: $CERT_PATH/fullchain.pem"
  echo " - Key: $CERT_PATH/privkey.pem"

  # Add cron job for SSL certificate renewal
  echo "Setting up a cron job for automatic SSL certificate renewal..."
  (crontab -l 2>/dev/null; echo "0 3 * * * /usr/bin/certbot renew --quiet --deploy-hook 'systemctl restart dns_manager'") | crontab -
  /usr/bin/certbot renew --dry-run --deploy-hook 'systemctl restart dns_manager'
  echo "Cron job added: SSL certificates will be renewed daily at 3 AM, and the Python server will restart upon renewal."

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "SSL/TLS configuration completed for $DOMAIN."
  echo "SSL certificates will renew automatically every 3 months."
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo ""

  # Disabling apparmor and ufw
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Disabling Apparmor and firewall to avoid DNS update errors..."
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  sudo systemctl stop apparmor
  sudo systemctl disable apparmor
  sudo ufw disable
  sudo systemctl disable ufw

  # End message if script worked properly
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo " 🎉 Configuration Complete! 🎉                          "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo ""
  echo "  ✅ BIND9 is installed, configured, and running successfully!"
  echo ""
  echo "  🌐 Domain '$DOMAIN' is now configured as a DNS zone."
  echo "   - Zone file: $ZONE_FILE"
  echo "   - Nameservers: ns1.$DOMAIN ($IP_ADDRESS), ns2.$DOMAIN ($IP_ADDRESS)"
  echo ""
  echo "  📄 To update DNS records dynamically, use 'nsupdate'."
  echo ""
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "- Script created by @StackMTL, all right reserved.      "
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo ""
  echo ""
  # Inform the user that the system needs a reboot
  echo "1" > "$SETUP_FILE"

  echo "To apply the changes, a system reboot is required."
  read -p "Do you want to reboot now? (y/n): " REBOOT_CHOICE

  if [[ "$REBOOT_CHOICE" == "y" || "$REBOOT_CHOICE" == "Y" || "$REBOOT_CHOICE" == "yes" || "$REBOOT_CHOICE" == "Yes" ]]; then
      echo "Rebooting the system now..."
      sudo reboot
  else
      echo "You chose not to reboot. Please remember to reboot the system manually to apply the changes."
      exit 1
  fi
fi

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "     🌐 DNS Manager Configuration Tool        "
echo "           Powered by StackMTL               "
echo "        Part 2: Instructions and Tests       "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check Setup state
if [ "$SETUP_STATE" == "1" ]; then
    echo
else
    echo "Error: Setup not initialized. Exiting..."
    echo "0" > "$SETUP_FILE"
    exit 1
fi

# Retrieve variables

# Main domain:
DOMAIN_PATH="/etc/DNS_MANAGER/.conf/main_domain.conf"

# Check if the domain file exists
if [ ! -f "$DOMAIN_PATH" ]; then
    echo "Error: Domain file $DOMAIN_PATH not found."
    exit 1
fi

# Read the first non-comment, non-empty line as the domain
DOMAIN=$(grep -vE '^\s*#' "$DOMAIN_PATH" | grep -vE '^\s*$' | head -n 1)

# Check if DOMAIN is valid
if [ -z "$DOMAIN" ]; then
    echo "Error: No valid domain found in $DOMAIN_PATH."
    exit 1
fi

echo "Domain extracted: $DOMAIN"

# IP Address:
IP_ADDRESS=$(hostname -I | awk '{print $1}')
echo "IP Address extracted: $IP_ADDRESS"

read -p "Do you need the instructions for using nsupdate? (y for yes)  " INSTRUCTION

if [ "$INSTRUCTION" = "y" ]; then
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  Instructions for Dynamic DNS Updates"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo "To dynamically update DNS records using nsupdate:"
    echo ""
    echo "1. Prepare an update file (e.g., update_dns.txt) with the following content:"
    echo "   server $IP_ADDRESS                    # Replace with your BIND9 server's IP if needed"
    echo "   zone $DOMAIN                          # Replace with your main domain if needed"
    echo "   update add mail.$DOMAIN 86400 TXT \"v=spf1 ip4:192.0.2.0 ip4:192.0.2.1 include:examplesender.email -all\""
    echo "   send"
    echo ""
    echo "2. Run the command:"
    echo "   nsupdate -v update_dns.txt"
    echo ""
    echo "This will securely send the DNS update to your server."
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
fi

echo ""
echo ""
read -p "Do you want to test a DNS update with nsupdate? (y for yes)  " TEST_UPDATE

if [ "$TEST_UPDATE" = "y" ]; then
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  Testing Dynamic DNS Updateds with nsupdate"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    # Create a temporary nsupdate test file
    NSUPDATE_TEST_FILE="/tmp/nsupdate_test.txt"
    TEST_HOST="test"
    TEST_IP="192.168.1.100"

    echo "Preparing a test to add record '${TEST_HOST}.${DOMAIN}' pointing to ${TEST_IP}..."
    cat <<EOF > $NSUPDATE_TEST_FILE
server 127.0.0.1
zone $DOMAIN
update add ${TEST_HOST}.${DOMAIN}. 86400 A $TEST_IP
send
EOF

    # Display the content of the test file
    echo "Test nsupdate file content:"
    cat $NSUPDATE_TEST_FILE
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    # Execute the nsupdate command to add the record
    echo "Executing nsupdate to add the record..."
    nsupdate -v $NSUPDATE_TEST_FILE

    # Check if the record was added successfully
    echo "Verifying the DNS record..."
    dig @127.0.0.1 ${TEST_HOST}.${DOMAIN} A +short

    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  Test Completed. Verify the output above.   "
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    # Prepare the file to delete the record
    echo "Preparing to delete the test record..."
    cat <<EOF > $NSUPDATE_TEST_FILE
server 127.0.0.1
zone $DOMAIN
update delete ${TEST_HOST}.${DOMAIN}. A
send
EOF

    # Display the content of the delete file
    echo "Delete nsupdate file content:"
    cat $NSUPDATE_TEST_FILE
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    # Execute the nsupdate command to delete the record
    echo "Executing nsupdate to delete the record..."
    nsupdate -v $NSUPDATE_TEST_FILE

    # Verify the record was deleted
    echo "Verifying the record has been deleted..."
    dig @127.0.0.1 ${TEST_HOST}.${DOMAIN} A

    # Clean up the test file
    rm -f $NSUPDATE_TEST_FILE

    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  Test record deleted successfully.          "
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
else
    echo "Skipping nsupdate test."
fi

read -p "Do you want to add authorized IPs for DNS updates? (y for yes) " ADD_IPS

if [ "$ADD_IPS" == "y" ]; then
    AUTHORIZED_IPS_FILE="/etc/DNS_MANAGER/.conf/authorized_ips.txt"

    # Ensure the authorized_ips.txt file exists
    sudo mkdir -p "$(dirname "$AUTHORIZED_IPS_FILE")"
    sudo touch "$AUTHORIZED_IPS_FILE"

    while true; do
        read -p "Enter an IP address to authorize (or press ENTER to finish): " IP_ADDRESS

        # Exit the loop if no input
        if [ -z "$IP_ADDRESS" ]; then
            echo "Finished adding IPs."
            break
        fi

        # Validate the IP address format (IPv4 only for simplicity)
        if [[ "$IP_ADDRESS" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] &&
           [[ "$IP_ADDRESS" -le 255 && "$IP_ADDRESS" -ge 0 ]]; then
            read -p "You entered '$IP_ADDRESS'. Do you confirm? (y/n): " CONFIRM

            if [[ "$CONFIRM" == "y" || "$CONFIRM" == "Y" ]]; then
                echo "$IP_ADDRESS" | sudo tee -a "$AUTHORIZED_IPS_FILE" > /dev/null
                echo "IP address '$IP_ADDRESS' added to the authorized list."
            else
                echo "IP address '$IP_ADDRESS' not added."
            fi
        else
            echo "Invalid IP address format. Please try again."
        fi
    done
    echo "Restarting dns_manager..."
    sudo systemctl restart dns_manager
    echo "Done!"
    echo "The following IPs are now authorized for updates:"
    cat "$AUTHORIZED_IPS_FILE"
else
    echo "Skipping IP authorization setup."
fi
