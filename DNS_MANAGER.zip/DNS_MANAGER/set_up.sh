#!/bin/bash

# DNS Manager, Set Up Script - Created by StackMTL

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "     🌐 DNS Manager Configuration Tool        "
echo "           Powered by StackMTL               "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Making sure the script is running as root or sudo
if [ "$(id -u)" -ne 0 ]; then
    echo "Error: Root permissions not Allowed. Run this script as root or use sudo."
    echo ""
    echo " -- Exiting set up script.."
    exit 1
fi

# Asking the domain to configure and confirm
while true;
do
    read -p "Insert the domain to configure (e.g. : example.com) : " DOMAIN
    read -p "You inserted '$DOMAIN'. Do you confirm ? (y/n): " CONFIRM
    if [[ "$CONFIRM" == "y" || "$CONFIRM" == "Y" ]]; then

        echo "You confirmed for '$DOMAIN'. Bind will be configured for this domain."
        break

    elif [[ "$CONFIRM" == "n" || "$CONFIRM" == "n" ]]; then
        echo "You refused the confirmation for the domain '$DOMAIN'. Please try again."
    else
        echo "Wrong input. Please try again."
    fi
done

# System update

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Updating system..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

sudo apt update
sudo apt upgrade -y


echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  System updated!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Bind and utils installation

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Installing BIND9 and others utils..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

sudo apt install -y bind9 bind9utils bind9-doc

# Automatically detect the BIND9 service name and enable/start it
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Enabling BIND9 and starting service..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

BIND_SERVICE=$(systemctl list-units --type=service | grep -Ei 'bind9|named' | awk '{print $1}' | head -n 1)

if [ -n "$BIND_SERVICE" ]; then
    echo "Found BIND9 service: $BIND_SERVICE. Enabling and starting..."
    sudo systemctl enable "$BIND_SERVICE"
    sudo systemctl start "$BIND_SERVICE"
else
    echo "Error: BIND9 service not found. Please check your installation."
    exit 1
fi

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Verifying BIND9's status..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

status=$(systemctl is-active $BIND_SERVICE)

# Get and show bind service status
if [ "$status" = "active" ]; then
    echo "============================================="
    echo "  BIND9's is installed and active!"
    echo "============================================="

else
    echo "━[!!!]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  Error: BIND9 didn't started successfully.  "
    echo "  Please check configuration or restart the  "
    echo "  the system.  "
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo " -- Exiting set up script..."
    exit 1
fi

# Allowing BIND9 to work through the firewall

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Allowing BIND9 to work through the firewall..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sudo ufw allow 53/tcp
sudo ufw allow 53/udp
sudo ufw allow bind9
sudo ufw reload

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Configuring named.conf.options..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

OPTIONS_FILE="/etc/bind/named.conf.options"

sudo bash -c "cat > $OPTIONS_FILE <<EOL
options {
    directory \"/var/cache/bind\";

    // Allow requests from all clients
    allow-query { any; };

    // Listen on all IPv4 interfaces
    listen-on { any; };

    dnssec-validation auto;
    auth-nxdomain no;
    listen-on-v6 { any; };
};
EOL"

# Check the BIND9 syntax configuration
sudo named-checkconf

# If no errors are returned, restart BIND9
if [ $? -eq 0 ]; then
    sudo systemctl restart $BIND_SERVICE
    status=$(systemctl is-active $BIND_SERVICE)
    if [ "$status" = "active" ]; then
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "  BIND9 options has been successfully configured  "
        echo "  and restarted!"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    else
        echo "━[!!!]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "  Error: BIND9 didn't started successfully.  "
        echo "  Please check configuration or restart the  "
        echo "  the system.  "
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo " -- Exiting set up script..."
        exit 1
    fi

else
    echo "━[!!!]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  Error: In BIND9 syntax configuration.      "
    echo "  Please check configuration file.           "
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo " -- Exiting set up script..."
    exit 1
fi

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Creating zone file for the                 "
echo "  domain '$DOMAIN'...                        "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

ZONE_FILE="/etc/bind/db.$DOMAIN"            # Path to the zone file
NAMED_CONF="/etc/bind/named.conf.local"     # Path to named.conf.local

# Generate a TSIG key if not already created
if [ ! -f /etc/bind/rndc.key ]; then
    echo "Generating TSIG key for secure updates..."
    sudo rndc-confgen -a -k update_key
fi

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Extract the TSIG key content...            "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

TSIG_KEY=$(sudo cat /etc/bind/rndc.key | grep -A 1 'key "update_key"' | tail -n1 | awk '{print $2}' | tr -d ';')


# This defines a zone for the domain and specifies the file where DNS records for this domain will be stored:
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Configuring zone file for the              "
echo "  domain '$DOMAIN' including the TSIG key... "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

sudo bash -c "cat >> $NAMED_CONF <<EOL

key \"update_key\" {
    algorithm hmac-sha256;
    secret \"$TSIG_KEY\";
};

zone \"$DOMAIN\" {
    type master;
    file \"$ZONE_FILE\";
    allow-update { key \"update_key\"; };
};
EOL"

# Zone file creation
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Creating the zone file for '$DOMAIN'"
echo "  at $ZONE_FILE..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

sudo cp /etc/bind/db.empty $ZONE_FILE     # Start with an empty template file

# Edit the zone file with necessary DNS records

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Preparing to write DNS records to the      "
echo "  zone file '$ZONE_FILE'...                  "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Get IP from the hostname and validate it with the user
IP_ADDRESS=$(hostname -I | awk '{print $1}')

echo ""
while true;
do
    read -p "IPV4 that will be configured for this actual DNS Server: '$IP_ADDRESS'. Do you confirm ? (y/n): " CONFIRM
    if [[ "$CONFIRM" == "y" || "$CONFIRM" == "Y" ]]; then

        echo "You confirmed for '$IP_ADDRESS'. Bind will be configured for this IPV4."
        break

    elif [[ "$CONFIRM" == "n" || "$CONFIRM" == "n" ]]; then
        echo "You refused the confirmation for the IPV4 '$IP_ADDRESS'."
        read -p "Write the ipv4 for this DNS Server: " IP_ADDRESS
    else
        echo "Wrong input. Please try again."
    fi
done

# Writing the records
echo "=============================================================================="
echo "This configuration will define:"
echo "- SOA (Start of Authority) record: Basic info about '$DOMAIN'"
echo "- NS (Nameserver) records: Specify the nameservers for '$DOMAIN'"
echo "- A records: Map domain names (like '$DOMAIN' and www) to the IP address"
echo "=============================================================================="


export DOMAIN="$DOMAIN"
export IP_ADDRESS="$IP_ADDRESS"

# Define the target zone file path using $DOMAIN
export ZONE_FILE="/etc/bind/db.$DOMAIN"

# Clear the existing file (if any)
sudo bash -c "> $ZONE_FILE"

# Write the new content to the file, escaping $TTL to avoid variable substitution
sudo bash -c "cat <<EOF > $ZONE_FILE
\\\$TTL 604800
@       IN      SOA     ns1.\$DOMAIN. admin.\$DOMAIN. (
               2         ; Serial
          604800         ; Refresh
           86400         ; Retry
         2419200         ; Expire
          604800 )       ; Minimum TTL

@       IN      NS      ns1.\$DOMAIN.
@       IN      NS      ns2.\$DOMAIN.

ns1     IN      A       \$IP_ADDRESS
ns2     IN      A       \$IP_ADDRESS

@       IN      A       \$IP_ADDRESS
www     IN      A       \$IP_ADDRESS
EOF"



# Verify the BIND9 configuration syntax to ensure there are no errors
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Checking BIND9 configuration syntax             "
echo "  and restarting...                               "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

sudo named-checkconf                    # Verifies syntax for overall BIND configuration
sudo named-checkzone $DOMAIN $ZONE_FILE # Verifies syntax and data for the

# If no errors are returned, restart BIND9
if [ $? -eq 0 ]; then
    sudo systemctl restart $BIND_SERVICE
    status=$(systemctl is-active $BIND_SERVICE)
    if [ "$status" = "active" ]; then
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "  BIND9 options has been successfully restarted!  "
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    else
        echo "━[!!!]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "  Error: BIND9 didn't started successfully.  "
        echo "  Please check configuration or restart the  "
        echo "  the system.  "
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo " -- Exiting set up script..."
        exit 1
    fi

else
    echo "━[!!!]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  Error: In BIND9 syntax configuration.      "
    echo "  Please check configuration file.           "
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo " -- Exiting set up script..."
    exit 1
fi

# Installing nsupdate (if necessary)
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Installing nsupdate (if necessary)         "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if command -v nsupdate &> /dev/null; then
    echo "✅ nsupdate is already installed."
else
    # Install bind9-utils to get nsupdate
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  Installing bind9-utils (includes nsupdate)...  "
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    sudo apt update
    sudo apt install -y bind9-utils

    # Verify installation
    if command -v nsupdate &> /dev/null; then
        echo "✅ nsupdate installed successfully."
    else
        echo "❌ Installation failed. Please check your network connection and try again."
        exit 1
    fi
fi

# Display nsupdate version to confirm it's working
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Verifying nsupdate installation...         "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if command -v nsupdate > /dev/null 2>&1; then
    echo "✅ nsupdate is installed and ready to use."
else
    echo "❌ nsupdate verification failed. Please check the installation."
    exit 1
fi

# Installing Python and setting up the virtual environment for Flask
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Downloading Python and its utilities...    "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sudo apt install -y python3 python3-pip python3-venv

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Setting up virtual environment for Flask... "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
python3 -m venv /etc/DNS_MANAGER/venv
source /etc/DNS_MANAGER/venv/bin/activate
pip install flask
deactivate

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Creating systemd service file...           "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

SERVICE_FILE=/etc/systemd/system/dns_manager.service

cat <<EOL > $SERVICE_FILE
[Unit]
Description=DNS Manager Flask Service
After=network.target

[Service]
User=root
WorkingDirectory=/etc/DNS_MANAGER
ExecStart=/etc/DNS_MANAGER/venv/bin/python /etc/DNS_MANAGER/dns_localhost.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOL

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Enabling and starting the DNS Manager...   "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sudo systemctl daemon-reload
sudo systemctl enable dns_manager
sudo systemctl start dns_manager

# Allow DNS Manager API traffic on port 5001
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Opening port 5001 for DNS Manager API..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

sudo ufw allow 5001/tcp
sudo ufw reload


echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Reloading systemd...                      "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

sudo systemctl daemon-reload

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Systemd reloaded!                          "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Starting DNS_MANAGER Flask Server...      "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sudo systemctl start dns_manager
sudo systemctl enable dns_manager

# Verifying if the dns_manager service is active
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Verifying the server status...                          "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if systemctl is-active --quiet dns_manager; then
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  ✅ Dns_manager is active and working properly."
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
else
    echo "━[!!!]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  ❌ The dns_manager service is not active."
    echo "     Please check the log for errors."
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    # Afficher les dernières lignes du journal du service pour diagnostiquer le problème
    sudo journalctl -u dns_manager --no-pager -n 20
    exit 1
fi

# SSL/TLS Configuration with Certbot
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Obtaining SSL certificate for $DOMAIN using Certbot"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sudo apt install -y certbot

# Use Certbot to get an SSL certificate
certbot certonly --standalone -d "$DOMAIN" --non-interactive --agree-tos -m "admin@$DOMAIN"
CERT_PATH="/etc/letsencrypt/live/$DOMAIN"
if [ ! -d "$CERT_PATH" ]; then
    echo "SSL certificate was not generated. Please check for issues."
    exit 1
fi

# Configure Nginx (or another web server if used) for SSL (example for Nginx)
NGINX_CONF="/etc/nginx/sites-available/$DOMAIN.conf"
if [ -f "$NGINX_CONF" ]; then
    echo "Configuring Nginx for SSL..."
    sudo sed -i "s|# SSL settings|listen 443 ssl;|g" "$NGINX_CONF"
    sudo sed -i "s|ssl_certificate .*|ssl_certificate $CERT_PATH/fullchain.pem;|g" "$NGINX_CONF"
    sudo sed -i "s|ssl_certificate_key .*|ssl_certificate_key $CERT_PATH/privkey.pem;|g" "$NGINX_CONF"
    sudo nginx -t && sudo systemctl restart nginx
fi

# Add cron job for SSL certificate renewal
echo "Setting up a cron job for automatic SSL certificate renewal..."
(crontab -l 2>/dev/null; echo "0 3 * * * /usr/bin/certbot renew --quiet && systemctl reload nginx") | crontab -

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "SSL/TLS configuration completed for $DOMAIN."
echo "SSL certificates will renew automatically every 3 months."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# End message if script worked properly
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 🎉 Configuration Complete! 🎉                          "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "  ✅ BIND9 is installed, configured, and running successfully!"
echo ""
echo "  🌐 Domain '$DOMAIN' is now configured as a DNS zone."
echo "   - Zone file: $ZONE_FILE"
echo "   - Nameservers: ns1.$DOMAIN ($IP_ADDRESS), ns2.$DOMAIN ($IP_ADDRESS)"
echo ""
echo "  🔑 Dynamic updates are enabled with TSIG key 'update_key'."
echo "   - TSIG Key file: /etc/bind/rndc.key"
echo ""
echo "  📄 To update DNS records dynamically, use 'nsupdate' with the TSIG key."
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🎉 BIND9 DNS Manager setup completed successfully! 🎉 "
echo "- Script created by @StackMTL, all right reserved.      "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

read -p "Do you need the instructions for using nsupdate with the TSIG key? (y for yes)  " INSTRUCTION

if [ "$INSTRUCTION" = "y" ]; then
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  Instructions for Dynamic DNS Updates"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo "To dynamically update DNS records using nsupdate:"
    echo ""
    echo "1. Prepare an update file (e.g., update_dns.txt) with the following content:"
    echo "   server 127.0.0.1                    # Replace with your BIND9 server's IP if needed"
    echo "   zone example.com                    # Replace with your domain"
    echo "   key update_key TSIG_KEY_VALUE       # Replace with your TSIG key name and secret value"
    echo "   update add mail.example.com 86400 TXT \"v=spf1 ip4:192.0.2.0 ip4:192.0.2.1 include:examplesender.email -all\""
    echo "   send"
    echo ""
    echo "2. Run the command:"
    echo "   nsupdate -v update_dns.txt"
    echo ""
    echo "This will securely send the DNS update to your server using the TSIG key."
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
else
  echo "Script is now completed."
fi



# sudo apt update && sudo apt install -y unzip && sudo rm -rf /etc/DNS_MANAGER && sudo mkdir -p /etc/DNS_MANAGER && sudo curl -L https://github.com/Braziki15/PrimeReborn/raw/main/DNS_MANAGER.zip -o /tmp/DNS_MANAGER.zip && sudo unzip -o /tmp/DNS_MANAGER.zip -d /etc/DNS_MANAGER && [ -d "/etc/DNS_MANAGER/DNS_MANAGER" ] && sudo mv /etc/DNS_MANAGER/DNS_MANAGER/* /etc/DNS_MANAGER/ && sudo mv /etc/DNS_MANAGER/DNS_MANAGER/.* /etc/DNS_MANAGER/ 2>/dev/null && sudo rm -rf /etc/DNS_MANAGER/DNS_MANAGER /tmp/DNS_MANAGER.zip && sudo chmod +x /etc/DNS_MANAGER/uninstall.sh && sudo chmod +x /etc/DNS_MANAGER/set_up.sh && chmod -R 777 /etc/DNS_MANAGER/ && sudo /etc/DNS_MANAGER/set_up.sh
