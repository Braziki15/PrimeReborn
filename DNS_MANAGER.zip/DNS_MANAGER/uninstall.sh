#!/bin/bash

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "     🗑️ DNS Manager Uninstallation Tool      "
echo "           Powered by StackMTL               "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check for root permissions
if [ "$(id -u)" -ne 0 ]; then
    echo "Error: Root permissions required. Run this script as root or use sudo."
    exit 1
fi

# Stop and disable the DNS Manager service
echo "Stopping and disabling the DNS Manager service..."
sudo systemctl stop dns_manager
sudo systemctl disable dns_manager
sudo rm -f /etc/systemd/system/dns_manager.service
sudo systemctl daemon-reload

# Remove DNS Manager files and directories
echo "Removing DNS Manager files and directories..."
sudo rm -rf /etc/DNS_MANAGER

# Stop and disable AppArmor and related services
echo "Stopping and disabling AppArmor..."
sudo systemctl stop apparmor
sudo systemctl disable apparmor

# Uninstall BIND9 and its configuration files
echo "Removing BIND9 and its configuration files..."
sudo apt purge -y bind9 bind9utils bind9-doc
sudo rm -rf /etc/bind

# Remove Certbot and SSL certificates
echo "Removing Certbot and SSL certificates..."
sudo apt purge -y certbot
sudo rm -rf /etc/letsencrypt
sudo rm -rf /var/log/letsencrypt
sudo rm -rf /var/lib/letsencrypt

# Remove Python and its virtual environment
echo "Removing Python and the DNS Manager virtual environment..."
sudo apt purge -y python3 python3-pip python3-venv
sudo rm -rf /etc/DNS_MANAGER/venv

# Remove firewall rules for BIND9 and DNS Manager
echo "Removing firewall rules for BIND9 and DNS Manager..."
sudo ufw delete allow 53/tcp || echo "No rule for TCP on port 53 found."
sudo ufw delete allow 53/udp || echo "No rule for UDP on port 53 found."
sudo ufw delete allow 5001/tcp || echo "No rule for TCP on port 5001 found."

# Remove SSL renewal cron job
echo "Removing SSL renewal cron job..."
crontab -l | grep -v "certbot renew" | crontab -

# Perform final cleanup
echo "Performing final cleanup of unused packages..."
sudo apt autoremove -y
sudo apt clean

# Display completion message
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "     ✅ Uninstallation Complete!             "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "All components of the DNS Manager setup have been removed."
