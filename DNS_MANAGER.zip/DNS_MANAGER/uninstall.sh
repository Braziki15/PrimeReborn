#!/bin/bash

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "     🗑️ DNS Manager Uninstallation Tool      "
echo "           Powered by StackMTL               "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check for root permissions
if [ "$(id -u)" -ne 0 ]; then
    echo "Error: Root permissions required. Run this script as root or use sudo."
    exit 1
fi

# Stop and disable the DNS Manager service
echo "Stopping and disabling the DNS Manager service..."
sudo systemctl stop dns_manager
sudo systemctl disable dns_manager
sudo rm /etc/systemd/system/dns_manager.service
sudo systemctl daemon-reload

# Remove DNS Manager files and directories
echo "Removing DNS Manager files..."
sudo rm -rf /etc/DNS_MANAGER

# Uninstall BIND9 and its configuration files (using named service name)
echo "Removing BIND9 and its configuration files..."
sudo systemctl stop named
sudo apt purge -y bind9 bind9utils bind9-doc
sudo rm -rf /etc/bind

# Uninstall Certbot and SSL certificates
echo "Removing Certbot and SSL certificates..."
sudo apt purge -y certbot
sudo rm -rf /etc/letsencrypt
sudo rm -rf /var/log/letsencrypt
sudo rm -rf /var/lib/letsencrypt

# Remove Python and associated packages (if only installed for DNS Manager)
echo "Removing Python and associated packages..."
sudo apt purge -y python3 python3-pip

# Remove firewall rule for BIND9
echo "Removing firewall rule for BIND9..."
sudo ufw delete allow 53/tcp
sudo ufw delete allow 53/udp
sudo ufw delete allow 5001/tcp

# Remove SSL renewal cron job
echo "Removing SSL renewal cron job..."
crontab -l | grep -v "certbot renew" | crontab -

# Final cleanup of unused packages
echo "Performing final cleanup..."
sudo apt autoremove -y
sudo apt clean

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "     ✅ Uninstallation Complete!             "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
