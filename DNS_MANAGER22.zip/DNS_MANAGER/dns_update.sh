#!/bin/bash

# DNS Manager, DNS Updater - Created by StackMTL

NSUPDATE_FILE=$1

if [ -z "$NSUPDATE_FILE" ]; then
  echo "Error: No nsupdate file provided."
  exit 1
fi

# Use nsupdate to apply changes
nsupdate -v "$NSUPDATE_FILE"
if [ $? -ne 0 ]; then
  echo "Failed to update DNS"
  exit 1
fi

echo "DNS updated successfully"
exit 0
