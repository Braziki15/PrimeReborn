#!/bin/bash

# Configure Postfix to listen on port 587 for relaying and sending
sudo sed -i '/^submission / s/^#//' /etc/postfix/master.cf
sudo sed -i '/^submission /,/^$/ s/^#//' /etc/postfix/master.cf
sudo sed -i '/^submission /,/^$/ s/-o smtpd_tls_auth_only=yes/-o smtpd_tls_auth_only=no/' /etc/postfix/master.cf

sudo systemctl restart postfix || { echo "Error: Failed to restart Postfix after enabling port 587."; exit 1; }
