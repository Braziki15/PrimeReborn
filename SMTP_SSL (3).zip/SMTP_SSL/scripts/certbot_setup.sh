#!/bin/bash

# Retrieve variables
# Main domain:
DOMAIN_PATH="/etc/DNS_MANAGER/.conf/domain.conf"

# Check if the domain file exists
if [ ! -f "$DOMAIN_PATH" ]; then
    echo "Error: Domain file $DOMAIN_PATH not found."
    exit 1
fi

# Read the first non-comment, non-empty line as the domain
DOMAIN=$(grep -vE '^\s*#' "$DOMAIN_PATH" | grep -vE '^\s*$' | head -n 1)

# Check if DOMAIN is valid
if [ -z "$DOMAIN" ]; then
    echo "Error: No valid domain found in $DOMAIN_PATH."
    exit 1
fi

# SSL/TLS Configuration
echo "Configuring SSL/TLS using Certbot..."
certbot certonly --standalone -d "$DOMAIN" --non-interactive --agree-tos -m "admin@$DOMAIN"
CERT_PATH="/etc/letsencrypt/live/$DOMAIN"
if [ ! -d "$CERT_PATH" ]; then
    echo "Error: SSL certificate generation failed."
    exit 1
fi

sudo postconf -e "smtpd_tls_cert_file=$CERT_PATH/fullchain.pem"
sudo postconf -e "smtpd_tls_key_file=$CERT_PATH/privkey.pem"
sudo systemctl restart postfix || { echo "Error: Failed to restart Postfix after SSL/TLS configuration."; exit 1; }
