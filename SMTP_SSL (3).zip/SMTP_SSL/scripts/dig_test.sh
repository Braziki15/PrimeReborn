#!/bin/bash

read -p "Do you want to test a DNS update with nsupdate? (y for yes)  " TEST_UPDATE
if [ "$TEST_UPDATE" = "y" ]; then

  # Path to the domain configuration file
  DOMAIN_PATH="/etc/DNS_MANAGER/.conf/domain.conf"

  # Check if the domain file exists
  if [ ! -f "$DOMAIN_PATH" ]; then
      echo "Error: Domain file $DOMAIN_PATH not found."
      exit 1
  fi

  # Read the first non-comment, non-empty line as the domain
  DOMAIN=$(grep -vE '^\s*#' "$DOMAIN_PATH" | grep -vE '^\s*$' | head -n 1)

  # Check if DOMAIN is valid
  if [ -z "$DOMAIN" ]; then
      echo "Error: No valid domain found in $DOMAIN_PATH."
      exit 1
  fi

  # Extract the main domain (without the subdomain)
  MAIN_DOMAIN=$(echo "$DOMAIN" | awk -F'.' '{if (NF>2) {print $(NF-1)"."$NF} else {print $0}}')

  # List of expected records for the subdomain
  declare -A RECORDS
  RECORDS["A"]="$DOMAIN"
  RECORDS["MX"]="$DOMAIN"
  RECORDS["TXT_spf"]="$DOMAIN"
  RECORDS["TXT_default._domainkey"]="$DOMAIN"
  RECORDS["TXT__dmarc"]="$DOMAIN"

  # Function to dig and check each record type
  dig_and_check() {
      local record_type=$1
      local host=$2

      echo "Checking $record_type record for $host on DNS server for $MAIN_DOMAIN..."
      dig_output=$(dig @"$MAIN_DOMAIN" +short "$host" "$record_type")
      if [ -z "$dig_output" ]; then
          echo "❌ Error: $record_type record for $host not found (Answer section is empty)."
          exit 1
      else
          echo "✅ $record_type record for $host found: $dig_output"
      fi
  }

  # Loop through the records and verify them
  for record_key in "${!RECORDS[@]}"; do
      case $record_key in
          "TXT_spf")
              dig_and_check "TXT" "${RECORDS[$record_key]}"
              ;;
          "TXT_default._domainkey")
              dig_and_check "TXT" "default._domainkey.${RECORDS[$record_key]}"
              ;;
          "TXT__dmarc")
              dig_and_check "TXT" "_dmarc.${RECORDS[$record_key]}"
              ;;
          *)
              dig_and_check "$record_key" "${RECORDS[$record_key]}"
              ;;
      esac
  done

  echo "✅ All DNS records for $DOMAIN verified successfully."
fi
