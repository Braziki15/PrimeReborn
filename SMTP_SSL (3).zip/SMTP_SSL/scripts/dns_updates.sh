#!/bin/bash

 # Retrieve variables
# Main domain:
DOMAIN_PATH="/etc/DNS_MANAGER/.conf/domain.conf"

# Check if the domain file exists
if [ ! -f "$DOMAIN_PATH" ]; then
    echo "Error: Domain file $DOMAIN_PATH not found."
    exit 1
fi

# Read the first non-comment, non-empty line as the domain
DOMAIN=$(grep -vE '^\s*#' "$DOMAIN_PATH" | grep -vE '^\s*$' | head -n 1)

# Check if DOMAIN is valid
if [ -z "$DOMAIN" ]; then
    echo "Error: No valid domain found in $DOMAIN_PATH."
    exit 1
fi

# Extract domain without the subdomain
MAIN_DOMAIN=$(echo "$DOMAIN" | awk -F'.' '{if (NF>2) {print $(NF-1)"."$NF} else {print $0}}')

# Retrieve the server IP associated with the main domain's A record
DNS_SERVER_IP=$(dig +short "$MAIN_DOMAIN" A | tail -n1)
if [ -z "$DNS_SERVER_IP" ]; then
    echo "Error: Unable to retrieve IP address for domain $MAIN_DOMAIN."
    exit 1
fi
echo "Detected server IP address for $MAIN_DOMAIN: $DNS_SERVER_IP"

# Configure OpenDKIM
echo "Setting up OpenDKIM for DKIM signing..."
sudo mkdir -p /etc/opendkim/keys/$DOMAIN
sudo tee /etc/opendkim.conf > /dev/null <<EOL
Syslog                  yes
UMask                   002
Canonicalization        relaxed/simple
Mode                    sv
SubDomains              no
Socket                  inet:8891@localhost
PidFile                 /var/run/opendkim/opendkim.pid
OversignHeaders         From
TrustAnchorFile         /usr/share/dns/root.key
UserID                  opendkim
KeyTable                refile:/etc/opendkim/KeyTable
SigningTable            refile:/etc/opendkim/SigningTable
ExternalIgnoreList      refile:/etc/opendkim/TrustedHosts
InternalHosts           refile:/etc/opendkim/TrustedHosts
EOL

sudo tee /etc/opendkim/KeyTable > /dev/null <<EOL
$DOMAIN    $DOMAIN:default:/etc/opendkim/keys/$DOMAIN/default.private
EOL

sudo tee /etc/opendkim/SigningTable > /dev/null <<EOL
*@${DOMAIN}    $DOMAIN
EOL

sudo tee /etc/opendkim/TrustedHosts > /dev/null <<EOL
127.0.0.1
localhost
$DOMAIN
$MAIN_DOMAIN
EOL

# Generate DKIM key
echo "Generating DKIM key for $DOMAIN..."
sudo opendkim-genkey -s default -d $DOMAIN
sudo mv default.private default.txt /etc/opendkim/keys/$DOMAIN
sudo chown -R opendkim:opendkim /etc/opendkim/keys/$DOMAIN

# Extract the DKIM value by keeping only the content between "(" and ")"
# Remove line breaks and unnecessary spaces in the value
clean_dkim_record=$(sed -n '/(/,/)/{s/.*(//; s/).*//; p}' /etc/opendkim/keys/blockchain.vps-network.com/default.txt | tr -d '\n\t' | sed 's/"//g' | sed 's/[ ]\+/ /g')

# Define DNS records explicitly
record1='{"action": "add", "zone": "'"$MAIN_DOMAIN"'", "host": "'"$DOMAIN"'", "type": "A", "value": "'"$SERVER_IP"'"}'
record2='{"action": "add", "zone": "'"$MAIN_DOMAIN"'", "host": "'"$DOMAIN"'", "type": "MX", "value": "10 '"$DOMAIN"'"}'
record3='{"action": "add", "zone": "'"$MAIN_DOMAIN"'", "host": "'"$MAIN_DOMAIN"'", "type": "TXT", "value": "v=spf1 a mx ip4:'"$SERVER_IP"' -all"}'
record4='{"action": "add", "zone": "'"$MAIN_DOMAIN"'", "host": "default._domainkey.'"$DOMAIN"'", "type": "TXT", "value": "'"$clean_dkim_record"'"}'
record5='{"action": "add", "zone": "'"$MAIN_DOMAIN"'", "host": "_dmarc.'"$DOMAIN"'", "type": "TXT", "value": "v=DMARC1; p=none; rua=mailto:dmarc-reports@'"$DOMAIN"'"}'

# Send records via DNS API
read -p "Do you want to automatically add these records via the DNS Manager API? (y/n): " AUTO_ADD
if [[ "$AUTO_ADD" == "y" || "$AUTO_ADD" == "Y" ]]; then
    read -p "Auto Through API: https://$MAIN_DOMAIN:5001/dns? (y for yes, else for custom API): " API_ANSWER
    if [[ "$API_ANSWER" == "y" || "$API_ANSWER" == "Y" ]]; then
        API_ENDPOINT="https://$MAIN_DOMAIN:5001/dns"
    else
        read -p "Enter the DNS Manager API endpoint (e.g., https://<dns_manager_ip>:5001/dns): " API_ENDPOINT
    fi

    echo "Adding records to DNS manager via API..."

    # Record 1
    echo "Sending record #1: $record1"
    response1=$(curl -s -X POST "$API_ENDPOINT" -H "Content-Type: application/json" -d "$record1")
    echo "Response for record #1: $response1"
    echo ""

    # Record 2
    echo "Sending record #2: $record2"
    response2=$(curl -s -X POST "$API_ENDPOINT" -H "Content-Type: application/json" -d "$record2")
    echo "Response for record #2: $response2"
    echo ""

    # Record 3
    echo "Sending record #3: $record3"
    response3=$(curl -s -X POST "$API_ENDPOINT" -H "Content-Type: application/json" -d "$record3")
    echo "Response for record #3: $response3"
    echo ""

    # Record 4
    echo "Sending record #4: $record4"
    response4=$(curl -s -X POST "$API_ENDPOINT" -H "Content-Type: application/json" -d "$record4")
    echo "Response for record #4: $response4"
    echo ""

    # Record 5
    echo "Sending record #5: $record5"
    response5=$(curl -s -X POST "$API_ENDPOINT" -H "Content-Type: application/json" -d "$record5")
    echo "Response for record #5: $response5"
    echo ""

    echo "All records have been processed."
fi
