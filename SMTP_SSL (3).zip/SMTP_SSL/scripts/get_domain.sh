#!/bin/bash

# Prompt for the full domain with subdomain and confirm
while true; do
    read -p "Enter the full domain (including subdomain) for this VPS: " DOMAIN
    # Validate domain format
    if [[ ! "$DOMAIN" =~ ^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$ ]]; then
        echo "Error: Invalid domain format. Retry please."

    else
      read -p "You entered '$DOMAIN'. Do you confirm? (y/n): " CONFIRM
      if [[ "$CONFIRM" == "y" || "$CONFIRM" == "Y" ]]; then
          break

      else
          echo "Invalid input. Please try again."

      fi
    fi
done

# Save domain in a config file
main_domain_file="/etc/SMTP_SSL/.conf/domain.conf"
cat > "$main_domain_file" <<EOL
# This is the main domain. Do not modify it.

$DOMAIN
EOL
