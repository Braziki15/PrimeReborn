#!/bin/bash

# Prompt for a username and validate it
while true; do
    read -p "Enter the SMTP username (e.g., no-reply): " USERNAME
    if [[ "$USERNAME" =~ ^[a-zA-Z0-9_-]+$ ]]; then
        echo "✅ Username '$USERNAME' is valid."
        break
    else
        echo "❌ Invalid username! Use only letters, numbers, underscores, or dashes."
    fi
done

# Generate a random password
PASSWORD=$(openssl rand -base64 16)

# Save user and pass in a config file
userpass_file="/etc/SMTP_SSL/.conf/userpass.conf"
cat > "$userpass_file" <<EOL
# This is the user and pass. Do not modify it.

u:$USERNAME
p:$PASSWORD
EOL
