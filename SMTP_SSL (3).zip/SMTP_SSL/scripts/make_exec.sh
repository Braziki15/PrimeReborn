#!/bin/bash

cd /etc/DNS_MANAGER/scripts/

chmod +x bypass_587.sh
chmod +x certbot_setup.sh
chmod +x dig_test.sh
chmod +x dns_updates.sh
chmod +x get_domain.sh
chmod +x get_user_pass.sh
chmod +x postfix_config.sh
chmod +x postfix_setup.sh
chmod +x ufw_apparmor_setup.sh
chmod +x userpass_setup.sh

cd /etc/SMTP_SSL/
