#!/bin/bash

# Retrieve variables
# Main domain:
DOMAIN_PATH="/etc/SSL_MANAGER/.conf/domain.conf"

# Check if the domain file exists
if [ ! -f "$DOMAIN_PATH" ]; then
    echo "Error: Domain file $DOMAIN_PATH not found."
    exit 1
fi

# Read the first non-comment, non-empty line as the domain
DOMAIN=$(grep -vE '^\s*#' "$DOMAIN_PATH" | grep -vE '^\s*$' | head -n 1)

# Check if DOMAIN is valid
if [ -z "$DOMAIN" ]; then
    echo "Error: No valid domain found in $DOMAIN_PATH."
    exit 1
fi

# Configure Postfix for standalone SMTP on port 587
echo "Configuring Postfix for $DOMAIN..."
sudo postconf -e "myhostname = $DOMAIN"
sudo postconf -e "mydomain = $DOMAIN"
sudo postconf -e "myorigin = \$myhostname"
sudo postconf -e "mydestination = \$myhostname, localhost.\$mydomain, localhost"
sudo postconf -e "relayhost = "  # No relayhost to deliver mail directly
sudo postconf -e "inet_interfaces = all"
sudo postconf -e "inet_protocols = ipv4"
sudo postconf -e "smtpd_tls_security_level = encrypt"
sudo postconf -e "smtp_tls_security_level = encrypt"
sudo postconf -e "smtpd_relay_restrictions = permit_sasl_authenticated, reject_unauth_destination"
sudo postconf -e "smtpd_recipient_restrictions = permit_mynetworks, permit_sasl_authenticated, reject_unauth_destination"
sudo postconf -e "smtpd_banner = \$myhostname ESMTP \$mail_name (Ubuntu)"
sudo postconf -e "smtpd_sasl_auth_enable = yes"
sudo postconf -e "smtpd_sasl_security_options = noanonymous"
sudo postconf -e "smtpd_tls_auth_only = yes"
sudo systemctl restart postfix || { echo "Error: Failed to restart Postfix."; exit 1; }
