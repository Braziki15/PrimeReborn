#!/bin/bash

# Installing bind for dig functions
sudo apt install bind9

# Preconfigure Postfix for "Internet Site" mode
echo "Preconfiguring Postfix for 'Internet Site' mode..."
echo "postfix postfix/main_mailer_type string 'Internet Site'" | sudo debconf-set-selections

# Install required software
echo "Installing Postfix, OpenDKIM, and Certbot..."
sudo apt install -y postfix opendkim opendkim-tools certbot || { echo "Error: Failed to install required packages."; exit 1; }


# Path to the main.cf file
MAIN_CF="/etc/postfix/main.cf"

# Check if main.cf exists; create it if missing
if [[ ! -f "$MAIN_CF" ]]; then
    echo "⚠️  main.cf not found. Creating an empty file..."
    sudo mkdir -p "$(dirname "$MAIN_CF")"  # Ensure the directory exists
    sudo touch "$MAIN_CF"                  # Create an empty main.cf file
    echo "✅ Created an empty main.cf at $MAIN_CF."
else
    echo "✅ main.cf already exists at $MAIN_CF."
fi
