#!/bin/bash

# Disabling apparmor and ufw
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Disabling Apparmor and firewall to avoid POSTFIX errors..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sudo systemctl stop apparmor
sudo systemctl disable apparmor
sudo ufw disable
sudo systemctl disable ufw

# Inform the user that the system needs a reboot
# Updating setup state
SETUP_FILE="/etc/SMTP_SSL/.conf/setup_continue"
echo "1" > "$SETUP_FILE"

echo "To apply the changes, a system reboot is required."
read -p "Do you want to reboot now? (y/n): " REBOOT_CHOICE

if [[ "$REBOOT_CHOICE" == "y" || "$REBOOT_CHOICE" == "Y" || "$REBOOT_CHOICE" == "yes" || "$REBOOT_CHOICE" == "Yes" ]]; then
    echo "Rebooting the system now... Restart the setup script to continue after reboot."
    sudo reboot
else
    echo "You chose not to reboot. Please remember to reboot the system manually to apply the changes."
    echo "Restart the setup script to continue after reboot."
    exit 1
fi