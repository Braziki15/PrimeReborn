#!/bin/bash

# Retrieve variables
# Main domain:
DOMAIN_PATH="/etc/DNS_MANAGER/.conf/domain.conf"

# Check if the domain file exists
if [ ! -f "$DOMAIN_PATH" ]; then
    echo "Error: Domain file $DOMAIN_PATH not found."
    exit 1
fi

# Read the first non-comment, non-empty line as the domain
DOMAIN=$(grep -vE '^\s*#' "$DOMAIN_PATH" | grep -vE '^\s*$' | head -n 1)

# Check if DOMAIN is set
if [[ -z "$DOMAIN" ]]; then
    echo "❌ DOMAIN variable is not set. Please set DOMAIN and rerun the script."
    exit 1
fi

# File containing the domain
userpass_file="/etc/SMTP_SSL/.conf/userpass.conf"

# Check if the file exists
if [[ -f "$userpass_file" ]]; then
    # Extract the username and password
    SMTP_USER=$(grep "^u:" "$userpass_file" | cut -d':' -f2)
    SMTP_PASS=$(grep "^p:" "$userpass_file" | cut -d':' -f2)

    # Display the extracted values
    if [[ -n "$USERNAME" && -n "$PASSWORD" ]]; then
        echo "📂 SMTP USERNAME and PASSWORD values extracted!"
    else
        echo "⚠️ Could not extract valid username or password from $userpass_file."
    fi
else
    echo "❌ Config file not found: $userpass_file"
fi

# Path to SASL password file
SASL_PASSWD_FILE="/etc/postfix/sasl_passwd"

# Check if inputs are not empty
if [[ -z "$SMTP_USER" || -z "$SMTP_PASS" ]]; then
    echo "❌ Username or password cannot be empty."
    exit 1
fi

# Add credentials to the SASL password file
echo "Storing credentials in $SASL_PASSWD_FILE..."
sudo mkdir -p "$(dirname "$SASL_PASSWD_FILE")"
echo "[smtp.$DOMAIN]:587 $SMTP_USER:$SMTP_PASS" | sudo tee "$SASL_PASSWD_FILE" > /dev/null

# Hash the password file for Postfix
echo "Hashing the password file..."
sudo postmap "$SASL_PASSWD_FILE"


# Update Postfix configuration for SASL authentication
echo "Updating Postfix configuration for SASL authentication..."
sudo postconf -e "smtp_sasl_password_maps = hash:$SASL_PASSWD_FILE"

# Restart Postfix to apply changes
echo "Restarting Postfix..."
sudo systemctl restart postfix