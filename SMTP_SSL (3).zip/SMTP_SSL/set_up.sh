#!/bin/bash

# VPS2SMTP + SSL/TLS Setup - Combined by StackMTL

# Making sure the script is running as root or sudo
if [ "$(id -u)" -ne 0 ]; then
    echo "Error: Root permissions not Allowed. Run this script as root or use sudo."
    echo ""
    echo " -- Exiting set up script.."
    exit 1
fi

# Check if the setup state file exists
SETUP_FILE="/etc/SMTP_SSL/.conf/setup_continue"

if [ ! -f "$SETUP_FILE" ]; then
    echo "File $SETUP_FILE not found. Creating it with the default value (0)."
    echo "0" > "$SETUP_FILE"
fi

# Read the setup state
SETUP_STATE=$(cat "$SETUP_FILE" | tr -d '[:space:]')  # Remove spaces or invisible characters

# Check the value
if [ "$SETUP_STATE" == "1" ]; then
    echo "Setup is in progress... (value 1 detected)"
elif [ "$SETUP_STATE" == "0" ]; then
    echo "Setup is not started or stopped. (value 0 detected)"
else
    echo "Invalid value detected in $SETUP_FILE. Resetting to 0."
    echo "0" > "$SETUP_FILE"
fi

# Cd to DNS_MANAGER setup dirname
cd /etc/SMTP_SSL/

if [ "$SETUP_STATE" == "0" ]; then

    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "     🌐 VPS2SMTP + SSL/TLS Configuration Tool "
    echo "           Powered by StackMTL               "
    echo "     Part 1: Firewall and Apparmor Config    "
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""

    # System update
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  Updating system..."
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    sudo apt update
    sudo apt upgrade -y
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  System updated!"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    # Making scripts executables
    chmod +x /etc/SMTP_SSL/scripts/make_exec.sh
    sudo ./scripts/make_exec.sh

    # Get domain from user
    sudo ./scripts/get_domain.sh

    # Get username from user and generate secured password
    sudo ./scripts/get_user_pass.sh

    # Installing Postfix and basic configurations
    sudo ./scripts/postfix_setup.sh

    # Firewall and Apparmor config + reboot
    sudo ./scripts/ufw_apparmor_setup.sh

    # Exiting first part of setup
    cd
    exit 0

elif [ "$SETUP_STATE" == "1" ]; then

    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "     🌐 VPS2SMTP + SSL/TLS Configuration Tool "
    echo "           Powered by StackMTL               "
    echo "        Part 2: Installations and Tests      "
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""

    # Full configs for Postfix
    sudo ./scripts/postfix_config.sh

    # Update records through API
    sudo ./scripts/dns_updates.sh

    # Get SSL
    sudo ./scripts/cerbot_setup.sh

    # Bypass port 25 to forward to port 587, allowing spamming
    sudo ./scripts/bypass_587.sh

    # Setup SMTP User and Password
    sudo ./scripts/userpass_setup.sh

    # Generate email address
    EMAIL="$USERNAME@$DOMAIN"

    # End message if script worked properly
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "     🎉 SMTP Configuration Complete! 🎉"
    echo "Note: Reboot your server to apply the changes"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo " 🌐 Domain:          $DOMAIN"
    echo " 📧 SMTP Server:     smtp.$MAIN_DOMAIN"
    echo " 🌍 IP Address:      $SERVER_IP"
    echo " 📤 Port:            587"
    echo " 👤 Email:           $EMAIL"
    echo " 🔑 Password:        $PASSWORD"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "Save these details securely!"

    # Verify records
    sudo ./scripts/dig_test.sh
fi
