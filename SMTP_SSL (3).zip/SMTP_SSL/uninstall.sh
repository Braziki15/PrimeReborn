#!/bin/bash

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "     🗑️ VPS2SMTP + SSL/TLS Uninstallation Tool"
echo "           Powerced by StackMTL               "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check for root permissions
if [ "$(id -u)" -ne 0 ]; then
    echo "Error: Root permissions required. Run this script as root or use sudo."
    exit 1
fi

# Stop and disable Postfix, OpenDKIM, and AppArmor services
echo "Stopping and disabling Postfix, OpenDKIM, and AppArmor services..."
sudo systemctl stop postfix
sudo systemctl disable postfix
sudo systemctl stop opendkim
sudo systemctl disable opendkim
sudo systemctl stop apparmor
sudo systemctl disable apparmor

# Remove Postfix, OpenDKIM, and bind
echo "Uninstalling Postfix, OpenDKIM, and Certbot..."0
sudo apt purge -y postfix opendkim opendkim-tools certbot || { echo "Error: Failed to uninstall packages."; exit 1; }

# Remove configuration files
echo "Removing Postfix, OpenDKIM, and Certbot configuration files..."
sudo rm -rf /etc/postfix
sudo rm -rf /etc/opendkim
sudo rm -rf /var/spool/postfix
sudo rm -rf /etc/letsencrypt
sudo rm -rf /var/log/letsencrypt
sudo rm -rf /var/lib/letsencrypt

# Remove saved DNS records file
echo "Removing saved DNS records file..."
rm -f dns4smtp.json

# Remove SSL renewal cron job
echo "Removing SSL renewal cron job..."
crontab -l | grep -v "certbot renew" | crontab -

# Re-enable UFW (Firewall)
echo "Re-enabling UFW (Firewall)..."
sudo systemctl enable ufw
sudo ufw enable || { echo "Error: Failed to enable UFW."; }

# Perform final cleanup of unused packages and cached data
echo "Performing final cleanup..."
sudo apt autoremove -y
sudo apt clean

# Display success message
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "     ✅ Uninstallation Complete!             "
echo "All components of the VPS2SMTP setup have been removed."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
