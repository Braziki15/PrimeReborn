#!/bin/bash

# VPS2SMTP + SSL/TLS Setup - Combined by StackMTL

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "     🌐 VPS2SMTP + SSL/TLS Configuration Tool     "
echo "           Powered by StackMTL                  "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo " ▸ This script will configure Postfix, OpenDKIM,"
echo "   and SSL/TLS for secure email sending on this VPS."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check for root permissions
if [ "$(id -u)" -ne 0 ]; then
    echo "Error: This script must be run as root."
    exit 1
fi

# Prompt for the full domain with subdomain and confirm
while true; do
    read -p "Enter the full domain (including subdomain) for this VPS: " DOMAIN
    read -p "You entered '$DOMAIN'. Do you confirm? (y/n): " CONFIRM
    if [[ "$CONFIRM" == "y" || "$CONFIRM" == "Y" ]]; then
        break
    else
        echo "Invalid input. Please try again."
    fi
done

# Extract the main domain
MAIN_DOMAIN=$(echo "$DOMAIN" | awk -F. '{print $(NF-1)"."$NF}')

# Prompt for a username and validate it
while true; do
    read -p "Enter the SMTP username (e.g., no-reply): " USERNAME
    if [[ "$USERNAME" =~ ^[a-zA-Z0-9_-]+$ ]]; then
        echo "✅ Username '$USERNAME' is valid."
        break
    else
        echo "❌ Invalid username! Use only letters, numbers, underscores, or dashes."
    fi
done

# Generate email address
EMAIL="$USERNAME@$DOMAIN"

# Generate a random password
PASSWORD=$(openssl rand -base64 16)

# Retrieve the server IP associated with the main domain's A record
SERVER_IP=$(dig +short "$MAIN_DOMAIN" A | tail -n1)
if [ -z "$SERVER_IP" ]; then
    echo "Error: Unable to retrieve IP address for domain $MAIN_DOMAIN."
    exit 1
fi
echo "Detected server IP address for $MAIN_DOMAIN: $SERVER_IP"

# Update packages
echo "Updating package lists..."
sudo apt update

# Preconfigure Postfix for "Internet Site" mode
echo "Preconfiguring Postfix for 'Internet Site' mode..."
echo "postfix postfix/main_mailer_type string 'Internet Site'" | sudo debconf-set-selections

# Install Postfix, OpenDKIM, and Certbot for SSL
echo "Installing Postfix, OpenDKIM, and Certbot..."
sudo apt install -y postfix opendkim opendkim-tools certbot

# Configure Postfix with the provided domain and generated user
echo "Configuring Postfix for $DOMAIN..."
sudo dpkg-reconfigure postfix
sudo postconf -e "myhostname = $DOMAIN"
sudo postconf -e "mydomain = $MAIN_DOMAIN"
sudo postconf -e "myorigin = \$myhostname"
sudo postconf -e "mydestination = \$myhostname, localhost.\$mydomain, localhost"
sudo postconf -e "relayhost = [smtp.$MAIN_DOMAIN]:587"
sudo postconf -e "smtp_sasl_auth_enable = yes"
sudo postconf -e "smtp_sasl_security_options = noanonymous"
sudo postconf -e "smtp_sasl_password_maps = hash:/etc/postfix/sasl_passwd"
sudo postconf -e "smtp_tls_security_level = encrypt"
sudo postconf -e "milter_default_action = accept"
sudo postconf -e "milter_protocol = 2"
sudo postconf -e "smtpd_milters = inet:localhost:8891"
sudo postconf -e "non_smtpd_milters = inet:localhost:8891"
sudo postconf -e "smtpd_banner = \$myhostname ESMTP \$mail_name (Ubuntu)"
sudo systemctl restart postfix

# Configure SMTP authentication
echo "Configuring SMTP authentication..."
sudo tee /etc/postfix/sasl_passwd > /dev/null <<EOL
[smtp.$MAIN_DOMAIN]:587 $EMAIL:$PASSWORD
EOL
sudo chmod 600 /etc/postfix/sasl_passwd
sudo postmap /etc/postfix/sasl_passwd
sudo systemctl restart postfix

# Configure OpenDKIM for DKIM signing
echo "Configuring OpenDKIM..."
sudo mkdir -p /etc/opendkim/keys
sudo tee /etc/opendkim.conf > /dev/null <<EOL
Syslog                  yes
UMask                   002
Canonicalization        relaxed/simple
Mode                    sv
SubDomains              no
Socket                  inet:8891@localhost
PidFile                 /var/run/opendkim/opendkim.pid
OversignHeaders         From
TrustAnchorFile         /usr/share/dns/root.key
UserID                  opendkim
KeyTable                refile:/etc/opendkim/KeyTable
SigningTable            refile:/etc/opendkim/SigningTable
ExternalIgnoreList      refile:/etc/opendkim/TrustedHosts
InternalHosts           refile:/etc/opendkim/TrustedHosts
EOL

sudo tee /etc/opendkim/KeyTable > /dev/null <<EOL
$DOMAIN    $DOMAIN:default:/etc/opendkim/keys/$DOMAIN/default.private
EOL

sudo tee /etc/opendkim/SigningTable > /dev/null <<EOL
*@${DOMAIN}    $DOMAIN
EOL

sudo tee /etc/opendkim/TrustedHosts > /dev/null <<EOL
127.0.0.1
localhost
$DOMAIN
$MAIN_DOMAIN
EOL

# Generate DKIM key
echo "Generating DKIM key for $DOMAIN..."
sudo mkdir -p /etc/opendkim/keys/$DOMAIN
sudo opendkim-genkey -s default -d $DOMAIN
sudo mv default.private default.txt /etc/opendkim/keys/$DOMAIN
sudo chown -R opendkim:opendkim /etc/opendkim/keys/$DOMAIN

# Save DNS records in dns4smtp.txt
dns_file="dns4smtp.txt"
echo "Saving DNS configuration records in $dns_file..."
echo "" > "$dns_file"
echo "SPF, DKIM, DMARC, MX, A records" | tee -a "$dns_file"
echo "$MAIN_DOMAIN IN TXT \"v=spf1 a mx ip4:$SERVER_IP -all\"" | tee -a "$dns_file"
echo "default._domainkey.$DOMAIN IN TXT \"$(awk 'BEGIN{ORS=""} {print}' /etc/opendkim/keys/$DOMAIN/default.txt)\"" | tee -a "$dns_file"
echo "_dmarc.$MAIN_DOMAIN IN TXT \"v=DMARC1; p=none; rua=mailto:dmarc-reports@$DOMAIN\"" | tee -a "$dns_file"
echo "$DOMAIN IN MX 10 $DOMAIN" | tee -a "$dns_file"
echo "$DOMAIN IN A $SERVER_IP" | tee -a "$dns_file"

# Add DNS records via API
read -p "Do you want to automatically add these records via the DNS Manager API? (y/n): " AUTO_ADD
if [[ "$AUTO_ADD" == "y" || "$AUTO_ADD" == "Y" ]]; then
    read -p "Enter the DNS Manager API endpoint (e.g., https://<dns_manager_ip>:5001/dns): " API_ENDPOINT

    echo "Adding records to DNS manager via API..."
    while IFS= read -r record; do
        name=$(echo "$record" | awk '{print $1}')
        type=$(echo "$record" | awk '{print $2}')
        value=$(echo "$record" | awk '{$1=""; $2=""; print $0}' | xargs)

        curl -X POST "$API_ENDPOINT" -H "Content-Type: application/json" -d "{\"zone\": \"$MAIN_DOMAIN\", \"host\": \"$name\", \"type\": \"$type\", \"value\": \"$value\", \"action\": \"add\"}"
    done < "$dns_file"
    echo "Records have been added via the DNS Manager API."
fi

# SSL/TLS Configuration with Certbot
echo "Obtaining SSL certificate for $DOMAIN using Certbot..."
certbot certonly --standalone -d "$DOMAIN" --non-interactive --agree-tos -m "admin@$DOMAIN"
CERT_PATH="/etc/letsencrypt/live/$DOMAIN"
if [ ! -d "$CERT_PATH" ]; then
  echo "SSL certificate was not generated. Please check for issues."
  exit 1
fi

# Configure Postfix for SSL
echo "Adding TLS configuration to Postfix..."
cat <<EOT | sudo tee -a /etc/postfix/main.cf
smtpd_tls_cert_file=$CERT_PATH/fullchain.pem
smtpd_tls_key_file=$CERT_PATH/privkey.pem
smtpd_use_tls=yes
smtpd_tls_security_level=may
smtp_tls_CAfile=/etc/ssl/certs/ca-certificates.crt
EOT
sudo systemctl restart postfix

# Display SMTP Information
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 🎉 SMTP Configuration Complete! 🎉"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 🌐 Domain:          $DOMAIN"
echo " 📧 SMTP Server:     smtp.$MAIN_DOMAIN"
echo " 🌍 IP Address:      $SERVER_IP"
echo " 📤 Port:            587"
echo " 👤 Username:        $EMAIL"
echo " 🔑 Password:        $PASSWORD"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "💡 Save these details securely!"
echo ""
