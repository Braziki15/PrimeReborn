#!/bin/bash

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "     🗑️ VPS2SMTP + SSL/TLS Uninstallation Tool"
echo "           Powered by StackMTL               "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check for root permissions
if [ "$(id -u)" -ne 0 ]; then
    echo "Error: Root permissions required. Run this script as root or use sudo."
    exit 1
fi

# Stop and disable Postfix and OpenDKIM services
echo "Stopping and disabling Postfix and OpenDKIM services..."
sudo systemctl stop postfix
sudo systemctl disable postfix
sudo systemctl stop opendkim
sudo systemctl disable opendkim

# Uninstall Postfix, OpenDKIM, and related tools
echo "Uninstalling Postfix, OpenDKIM, and related tools..."
sudo apt purge -y postfix opendkim opendkim-tools

# Remove Postfix and OpenDKIM configuration files
echo "Removing Postfix and OpenDKIM configuration files..."
sudo rm -rf /etc/postfix
sudo rm -rf /etc/opendkim
sudo rm -rf /var/spool/postfix

# Uninstall Certbot and remove SSL certificates
echo "Uninstalling Certbot and removing SSL certificates..."
sudo apt purge -y certbot
sudo rm -rf /etc/letsencrypt
sudo rm -rf /var/log/letsencrypt
sudo rm -rf /var/lib/letsencrypt

# Remove saved DNS records file
echo "Removing DNS records file..."
rm -f dns4smtp.txt

# Remove SSL renewal cron job
echo "Removing SSL renewal cron job..."
crontab -l | grep -v "certbot renew" | crontab -

# Final cleanup of unused packages
echo "Performing final cleanup..."
sudo apt autoremove -y
sudo apt clean

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "     ✅ Uninstallation Complete!             "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
