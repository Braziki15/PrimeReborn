#!/bin/bash

# VPS2SMTP + SSL/TLS Setup - Combined by StackMTL

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "     🌐 VPS2SMTP + SSL/TLS Configuration Tool     "
echo "           Powered by StackMTL                  "
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check for root permissions
if [ "$(id -u)" -ne 0 ]; then
    echo "Error: This script must be run as root."
    exit 1
fi

# Disable UFW (Firewall)
echo "Disabling UFW to allow all required ports..."
sudo ufw disable
sudo systemctl disable ufw
sudo systemctl stop apparmor
sudo systemctl disable apparmor

# Prompt for the full domain with subdomain and confirm
while true; do
    read -p "Enter the full domain (including subdomain) for this VPS: " DOMAIN
    read -p "You entered '$DOMAIN'. Do you confirm? (y/n): " CONFIRM
    if [[ "$CONFIRM" == "y" || "$CONFIRM" == "Y" ]]; then
        break
    else
        echo "Invalid input. Please try again."
    fi
done

# Validate domain format
if [[ ! "$DOMAIN" =~ ^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$ ]]; then
    echo "Error: Invalid domain format. Exiting."
    exit 1
fi

# Extract the main domain
MAIN_DOMAIN=$(echo "$DOMAIN" | awk -F. '{print $(NF-1)"."$NF}')

# Prompt for a username and validate it
while true; do
    read -p "Enter the SMTP username (e.g., no-reply): " USERNAME
    if [[ "$USERNAME" =~ ^[a-zA-Z0-9_-]+$ ]]; then
        echo "✅ Username '$USERNAME' is valid."
        break
    else
        echo "❌ Invalid username! Use only letters, numbers, underscores, or dashes."
    fi
done

# Generate email address
EMAIL="$USERNAME@$DOMAIN"

# Generate a random password
PASSWORD=$(openssl rand -base64 16)

# Retrieve the server IP associated with the main domain's A record
SERVER_IP=$(dig +short "$MAIN_DOMAIN" A | tail -n1)
if [ -z "$SERVER_IP" ]; then
    echo "Error: Unable to retrieve IP address for domain $MAIN_DOMAIN."
    exit 1
fi
echo "Detected server IP address for $MAIN_DOMAIN: $SERVER_IP"

# Update system packages
echo "Updating system packages..."
sudo apt update && sudo apt upgrade -y || { echo "Error: Failed to update system packages."; exit 1; }

# Preconfigure Postfix for "Internet Site" mode
echo "Preconfiguring Postfix for 'Internet Site' mode..."
echo "postfix postfix/main_mailer_type string 'Internet Site'" | sudo debconf-set-selections

# Install required software
echo "Installing Postfix, OpenDKIM, and Certbot..."
sudo apt install -y postfix opendkim opendkim-tools certbot || { echo "Error: Failed to install required packages."; exit 1; }

# Configure Postfix for standalone SMTP on port 587
echo "Configuring Postfix for $DOMAIN..."
sudo postconf -e "myhostname = $DOMAIN"
sudo postconf -e "mydomain = $MAIN_DOMAIN"
sudo postconf -e "myorigin = \$myhostname"
sudo postconf -e "mydestination = \$myhostname, localhost.\$mydomain, localhost"
sudo postconf -e "relayhost = "  # No relayhost to deliver mail directly
sudo postconf -e "inet_interfaces = all"
sudo postconf -e "inet_protocols = ipv4"
sudo postconf -e "smtpd_tls_cert_file=/etc/letsencrypt/live/$DOMAIN/fullchain.pem"
sudo postconf -e "smtpd_tls_key_file=/etc/letsencrypt/live/$DOMAIN/privkey.pem"
sudo postconf -e "smtpd_tls_security_level = encrypt"
sudo postconf -e "smtp_tls_security_level = encrypt"
sudo postconf -e "smtpd_relay_restrictions = permit_sasl_authenticated, reject_unauth_destination"
sudo postconf -e "smtpd_recipient_restrictions = permit_mynetworks, permit_sasl_authenticated, reject_unauth_destination"
sudo postconf -e "smtpd_banner = \$myhostname ESMTP \$mail_name (Ubuntu)"
sudo postconf -e "smtpd_sasl_auth_enable = yes"
sudo postconf -e "smtpd_sasl_security_options = noanonymous"
sudo postconf -e "smtpd_tls_auth_only = yes"
sudo systemctl restart postfix || { echo "Error: Failed to restart Postfix."; exit 1; }

# Configure Postfix to listen on port 587 for relaying and sending
sudo sed -i '/^submission / s/^#//' /etc/postfix/master.cf
sudo sed -i '/^submission /,/^$/ s/^#//' /etc/postfix/master.cf
sudo sed -i '/^submission /,/^$/ s/-o smtpd_tls_auth_only=yes/-o smtpd_tls_auth_only=no/' /etc/postfix/master.cf

sudo systemctl restart postfix || { echo "Error: Failed to restart Postfix after enabling port 587."; exit 1; }

# Configure OpenDKIM
echo "Setting up OpenDKIM for DKIM signing..."
sudo mkdir -p /etc/opendkim/keys/$DOMAIN
sudo tee /etc/opendkim.conf > /dev/null <<EOL
Syslog                  yes
UMask                   002
Canonicalization        relaxed/simple
Mode                    sv
SubDomains              no
Socket                  inet:8891@localhost
PidFile                 /var/run/opendkim/opendkim.pid
OversignHeaders         From
TrustAnchorFile         /usr/share/dns/root.key
UserID                  opendkim
KeyTable                refile:/etc/opendkim/KeyTable
SigningTable            refile:/etc/opendkim/SigningTable
ExternalIgnoreList      refile:/etc/opendkim/TrustedHosts
InternalHosts           refile:/etc/opendkim/TrustedHosts
EOL

sudo tee /etc/opendkim/KeyTable > /dev/null <<EOL
$DOMAIN    $DOMAIN:default:/etc/opendkim/keys/$DOMAIN/default.private
EOL

sudo tee /etc/opendkim/SigningTable > /dev/null <<EOL
*@${DOMAIN}    $DOMAIN
EOL

sudo tee /etc/opendkim/TrustedHosts > /dev/null <<EOL
127.0.0.1
localhost
$DOMAIN
$MAIN_DOMAIN
EOL

# Generate DKIM key
echo "Generating DKIM key for $DOMAIN..."
sudo opendkim-genkey -s default -d $DOMAIN
sudo mv default.private default.txt /etc/opendkim/keys/$DOMAIN
sudo chown -R opendkim:opendkim /etc/opendkim/keys/$DOMAIN

# Extract the DKIM value by keeping only the content between "(" and ")"
# Remove line breaks and unnecessary spaces in the value
clean_dkim_record=$(sed -n '/(/,/)/{s/.*(//; s/).*//; p}' /etc/opendkim/keys/blockchain.vps-network.com/default.txt | tr -d '\n\t' | sed 's/"//g' | sed 's/[ ]\+/ /g')

# Define DNS records explicitly
record1='{"action": "add", "zone": "'"$MAIN_DOMAIN"'", "host": "'"$DOMAIN"'", "type": "A", "value": "'"$SERVER_IP"'"}'
record2='{"action": "add", "zone": "'"$MAIN_DOMAIN"'", "host": "'"$DOMAIN"'", "type": "MX", "value": "10 '"$DOMAIN"'"}'
record3='{"action": "add", "zone": "'"$MAIN_DOMAIN"'", "host": "'"$MAIN_DOMAIN"'", "type": "TXT", "value": "v=spf1 a mx ip4:'"$SERVER_IP"' -all"}'
record4='{"action": "add", "zone": "'"$MAIN_DOMAIN"'", "host": "default._domainkey.'"$DOMAIN"'", "type": "TXT", "value": "'"$clean_dkim_record"'"}'
record5='{"action": "add", "zone": "'"$MAIN_DOMAIN"'", "host": "_dmarc.'"$DOMAIN"'", "type": "TXT", "value": "v=DMARC1; p=none; rua=mailto:dmarc-reports@'"$DOMAIN"'"}'

# Send records via DNS API
read -p "Do you want to automatically add these records via the DNS Manager API? (y/n): " AUTO_ADD
if [[ "$AUTO_ADD" == "y" || "$AUTO_ADD" == "Y" ]]; then
    read -p "Enter the DNS Manager API endpoint (e.g., https://<dns_manager_ip>:5001/dns): " API_ENDPOINT

    echo "Adding records to DNS manager via API..."

    # Record 1
    echo "Sending record #1: $record1"
    response1=$(curl -s -X POST "$API_ENDPOINT" -H "Content-Type: application/json" -d "$record1")
    echo "Response for record #1: $response1"
    echo ""

    # Record 2
    echo "Sending record #2: $record2"
    response2=$(curl -s -X POST "$API_ENDPOINT" -H "Content-Type: application/json" -d "$record2")
    echo "Response for record #2: $response2"
    echo ""

    # Record 3
    echo "Sending record #3: $record3"
    response3=$(curl -s -X POST "$API_ENDPOINT" -H "Content-Type: application/json" -d "$record3")
    echo "Response for record #3: $response3"
    echo ""

    # Record 4
    echo "Sending record #4: $record4"
    response4=$(curl -s -X POST "$API_ENDPOINT" -H "Content-Type: application/json" -d "$record4")
    echo "Response for record #4: $response4"
    echo ""

    # Record 5
    echo "Sending record #5: $record5"
    response5=$(curl -s -X POST "$API_ENDPOINT" -H "Content-Type: application/json" -d "$record5")
    echo "Response for record #5: $response5"
    echo ""

    echo "All records have been processed."
fi


# SSL/TLS Configuration
echo "Configuring SSL/TLS using Certbot..."
certbot certonly --standalone -d "$DOMAIN" --non-interactive --agree-tos -m "admin@$DOMAIN"
CERT_PATH="/etc/letsencrypt/live/$DOMAIN"
if [ ! -d "$CERT_PATH" ]; then
    echo "Error: SSL certificate generation failed."
    exit 1
fi

sudo postconf -e "smtpd_tls_cert_file=$CERT_PATH/fullchain.pem"
sudo postconf -e "smtpd_tls_key_file=$CERT_PATH/privkey.pem"
sudo systemctl restart postfix || { echo "Error: Failed to restart Postfix after SSL/TLS configuration."; exit 1; }

# Display setup information
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "     🎉 SMTP Configuration Complete! 🎉"
echo "Note: Reboot your server to apply the changes"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 🌐 Domain:          $DOMAIN"
echo " 📧 SMTP Server:     smtp.$MAIN_DOMAIN"
echo " 🌍 IP Address:      $SERVER_IP"
echo " 📤 Port:            587"
echo " 👤 Username:        $EMAIL"
echo " 🔑 Password:        $PASSWORD"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Save these details securely!"
